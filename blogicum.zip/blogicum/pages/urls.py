from django.urls import path
from django.conf.urls import handler404, handler500

from .views import (AboutView, RulesView, PageNotFoundView)

app_name = 'pages'

handler404 = PageNotFoundView.as_view()
handler500 = "pages.views.internal_server_error"

urlpatterns = [
    path("about/", AboutView.as_view(), name="about"),
    path("rules/", RulesView.as_view(), name="rules"),

]
